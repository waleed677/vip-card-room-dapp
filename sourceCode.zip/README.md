# Metaverse Secret NFT's Mint Page

![](https://raw.githubusercontent.com/waleed677/Joking-Jungle-Cats-Mint-Page/master/public/config/images/banner.jpeg)

## Website Link

https://mint.metaversessecret.com/

# From Fleek Access
https://delicate-silence-7993.on.fleek.co/


## Installation

1. Clone the Repository
2. go to root folder of the project
3. run ``` npm install ``` 
4. run ```npm run start ``` 


## Technology 

1. React Js
2. Redux for state management
3. For UI used styled components
4. For Smart Contract Used Solidity Language


# Contract Address



You can hire me for blockchain work on

https://www.Fiverr.com/waleed_arshad1

