import styled from "styled-components";

export const StyledLink = styled.a`
  color: var(--secondary);
  text-decoration: none;
`;